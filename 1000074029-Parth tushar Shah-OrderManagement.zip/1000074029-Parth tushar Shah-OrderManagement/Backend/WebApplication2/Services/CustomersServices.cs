﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Models;
using WebApplication2.Data;
using AutoMapper;

namespace WebApplication2.Services
{
    public class CustomersServices : ICustomersRepository
    {
        private readonly OrderProject74029Context _context;
        private IMapper _mapper;
        public CustomersServices(OrderProject74029Context context,IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }
        public CustomersServices(OrderProject74029Context context)
        {
            _context = context;
        }

        public IEnumerable<Customers> GetCustomers()
        {
            try
            {
                return _context.Customers;
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public CustomersVM GetCustomerById(int id)
        {
            try
            {
                var customers = _context.Customers.FirstOrDefault(i =>i.Customerid==id);
                var item = _mapper.Map<CustomersVM>(customers);
                return item;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public CustomersVM GetByEmail(string email)
        {
            try
            {
                var customer = _context.Customers.FirstOrDefault(i => i.Customeremail == email);
                var item = _mapper.Map<CustomersVM>(customer);
                return item;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public CustomersVM PutCustomers(int id, CustomersVM customer)
        {
            try
            {
                var data = _context.Customers.FirstOrDefault(i => i.Customerid == id);
                var _customer = _mapper.Map<CustomersVM>(data);
                if (customer != null)
                {
                    _customer.Customername = customer.Customername;
                    _customer.Customeremail = customer.Customeremail;
                    _customer.Customerpassword = customer.Customerpassword;
                    _context.SaveChanges();
                }
                return _customer;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public void PostCustomers(CustomersVM customer)
        {
            try
            {
                var data = _mapper.Map<Customers>(customer);
                _context.Add(data);
                _context.SaveChanges();
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public void DeleteCustomers(int id)
        {
            try
            {
                var _customer = _context.Customers.FirstOrDefault(i => i.Customerid == id);
                if (_customer != null)
                {
                    _context.Remove(_customer);
                    _context.SaveChanges();
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

    }
}
