﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Models;

namespace WebApplication2.Services
{
    public interface IOrderItemsRepository
    {
        List<OrderItems> GetOrderItems();
        OrderItems GetOrderItems(int id);
        List<OrderItems> GetOrderItemByCustomer(int id);
        List<OrderItems> GetOrderedItems(int customerid, int orderid);
        OrderItems PutOrderItems(int id, OrderItems item);
        void PostOrderItems(OrderItems item);
        void DeleteOrderItems(int id);

    }
}
