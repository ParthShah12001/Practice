﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Models;

namespace WebApplication2.Services
{
    public class OrderItemsServices : IOrderItemsRepository
    {
        private readonly OrderProject74029Context _context;
        public OrderItemsServices(OrderProject74029Context context)
        {
            _context = context;
        }
        public List<OrderItems> GetOrderItems()
        {
            try
            {
                return _context.OrderItems.ToList();
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public OrderItems GetOrderItems(int id)
        {
            try
            {
                var item = _context.OrderItems.Find(id);
                return item;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public List<OrderItems> GetOrderItemByCustomer(int id)
        {
            try
            {
                var item = _context.OrderItems.Where(i => i.Customerid == id).ToList();
                return item;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public List<OrderItems> GetOrderedItems(int customerid, int orderid)
        {
            try
            {
                var item = _context.OrderItems.Where(i => i.Customerid == customerid && i.Orderid == orderid).ToList();
                return item;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public OrderItems PutOrderItems(int id, OrderItems item)
        {
            try
            {
                var _item = _context.OrderItems.FirstOrDefault(i => i.Itemid == id);
                if (_item != null)
                {
                    _item.Productid = item.Productid;
                    _item.Customerid = item.Customerid;
                    _item.Orderid = item.Orderid;
                    _item.Quantity = item.Quantity;
                    _item.Stat = item.Stat;
                    _item.Price = item.Price;
                    _context.SaveChanges();
                }
                return _item;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public void PostOrderItems(OrderItems item)
        {
            try
            {
                _context.Add(item);
                _context.SaveChanges();
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public void DeleteOrderItems(int id)
        {
            try
            {
                var item = _context.OrderItems.Find(id);
                _context.Remove(item);
                _context.SaveChanges();
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    }
}
