﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Data;
using WebApplication2.Models;

namespace WebApplication2.Services
{
    public class CartItemsServices : ICartItemsRepository
    {
        private readonly OrderProject74029Context _context;
        private IMapper _mapper;
        public CartItemsServices(OrderProject74029Context context,IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public List<CartItemsVM> GetCartItems()
        {
            try
            {
                var data =  _context.CartItems.ToList();
                var items = _mapper.Map<List<CartItemsVM>>(data);
                return items;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public CartItemsVM GetCartItems(int id)
        {
            try
            {
                var data = _context.CartItems.FirstOrDefault(i =>i.Itemid==id);
                var item = _mapper.Map<CartItemsVM>(data);
                return item;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public decimal GetTotalPrice(int id)
        {
            try
            {
                var total = _context.CartItems.Where(i => i.Customerid == id).Sum(i => i.Productprice);
                return total;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public List<CartItemsVM> GetCartItemsByCustomers(int id)
        {
            try
            {
                var data =  _context.CartItems.Where(i => i.Customerid == id).ToList();
                var items = _mapper.Map<List<CartItemsVM>>(data);
                return items;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public CartItemsVM PutCartItems(int id, CartItemsVM cartItem)
        {
            try
            {
                var data = _context.CartItems.FirstOrDefault(i => i.Itemid == id);
                var _item = _mapper.Map<CartItemsVM>(data);
                if (_item != null)
                {
                    _item.Productid = cartItem.Productid;
                    _item.Productquantity = cartItem.Productquantity;
                    _item.Productprice = cartItem.Productprice;
                    _item.Customerid = cartItem.Customerid;
                    _context.SaveChanges();
                }
                return _item;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public void PostCartItems(CartItemsVM cartItem)
        {
            try
            {
                var item = _mapper.Map<CartItems>(cartItem);
                _context.Add(item);
                _context.SaveChanges();
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public void DeleteCartItems(int id)
        {
            try
            {
                var _item = _context.CartItems.FirstOrDefault(i => i.Itemid == id);
                if (_item != null)
                {
                    _context.Remove(_item);
                    _context.SaveChanges();
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    }
}
