﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Data;
using WebApplication2.Models;

namespace WebApplication2.Services
{
    public class ProductsServices:IProductsRepository
    {
        private readonly OrderProject74029Context _context;
        private IMapper _mapper;
        public ProductsServices(OrderProject74029Context context,IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public List<ProductsVM> GetProducts()
        {
            try
            {
                var item = _context.Products.ToList();
                var data = _mapper.Map<List<ProductsVM>>(item);
                return data;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public ProductsVM GetProducts(int id)
        {
            try
            {
                var item = _context.Products.FirstOrDefault(i => i.Productid==id);
                var data = _mapper.Map<ProductsVM>(item);
                return data;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public ProductsVM PutProducts(int id, ProductsVM product)
        {
            try
            {
                var data = _context.Products.FirstOrDefault(i => i.Productid == id);
                var item = _mapper.Map<ProductsVM>(data);
                if (item != null)
                {
                    item.Productname = product.Productname;
                    item.Productdetails = product.Productdetails;
                    item.Productprice = product.Productprice;
                    item.Productquantity = product.Productquantity;
                    _context.SaveChanges();
                }
                return item;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public void PostProducts(ProductsVM product)
        {
            try
            {
                var data = _mapper.Map<Products>(product);
                _context.Add(data);
                _context.SaveChanges();
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public void DeleteProducts(int id)
        {
            try
            {
                var item = _context.Products.Find(id);
                if (item != null)
                {
                    _context.Remove(item);
                    _context.SaveChanges();
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

    }
}
