﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Data;
using WebApplication2.Models;

namespace WebApplication2.Services
{
    public interface IOrdersRepository
    {
        List<OrdersVM> GetOrders();
        OrdersVM GetOrders(int id);
        List<OrdersVM> GetOrderedItems(int id);
        OrdersVM GetLastOrder();
        OrdersVM PutOrders(int id, OrdersVM order);
        void PostOrders(OrdersVM order);
        void DeleteOrders(int id);
    }
}
