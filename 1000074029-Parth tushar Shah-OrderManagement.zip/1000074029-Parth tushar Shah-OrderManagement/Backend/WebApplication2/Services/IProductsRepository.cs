﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Data;
using WebApplication2.Models;

namespace WebApplication2.Services
{
    public interface IProductsRepository
    {
        List<ProductsVM> GetProducts();
        ProductsVM GetProducts(int id);
        ProductsVM PutProducts(int id, ProductsVM product);
        void PostProducts(ProductsVM product);
        void DeleteProducts(int id);

    }
}
