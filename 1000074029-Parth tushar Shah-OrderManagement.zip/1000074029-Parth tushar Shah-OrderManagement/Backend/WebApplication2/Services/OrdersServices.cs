﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Data;
using WebApplication2.Models;

namespace WebApplication2.Services
{
    public class OrdersServices : IOrdersRepository
    {
        private readonly OrderProject74029Context _context;
        private IMapper _mapper;
        public OrdersServices(OrderProject74029Context context,IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }
        public List<OrdersVM> GetOrders()
        {
            try
            {
                var item =  _context.Orders.ToList();
                var data = _mapper.Map<List<OrdersVM>>(item);
                return data;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public OrdersVM GetOrders(int id)
        {
            try
            {
                var item =  _context.Orders.FirstOrDefault(i => i.Orderid==id);
                var data = _mapper.Map<OrdersVM>(item);
                return data;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<OrdersVM> GetOrderedItems(int id)
        {
            try
            {
                var item = _context.Orders.Where(i => i.Customerid == id).ToList();
                item.Reverse();
                var data = _mapper.Map<List<OrdersVM>>(item);
                return data;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public OrdersVM GetLastOrder()
        {
            try
            {
                var orders = _context.Orders.FromSql("Select * from Orders where orderid=(select max(orderid) from Orders)").FirstOrDefault();
                var data = _mapper.Map<OrdersVM>(orders);
                return data;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public OrdersVM PutOrders(int id, OrdersVM order)
        {
            try
            {
                var data = _context.Orders.FirstOrDefault(i => i.Orderid == id);
                var item = _mapper.Map<OrdersVM>(data);
                if (item != null)
                {
                    item.Customerid = order.Customerid;
                    item.Totalprice = order.Totalprice;
                    item.PaymentMethod = order.PaymentMethod;
                    item.Addres = order.Addres;
                    item.City = order.City;
                    item.Region = order.Region;
                    item.Orderdate = order.Orderdate;
                    _context.SaveChanges();
                }
                return item;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void PostOrders(OrdersVM order)
        {
            try
            {
                var data = _mapper.Map<Orders>(order);
                _context.Add(data);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void DeleteOrders(int id)
        {
            try
            {
                var item = _context.Orders.Find(id);
                if (item != null)
                {
                    _context.Remove(item);
                    _context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
