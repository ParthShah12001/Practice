﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Data;
using WebApplication2.Models;

namespace WebApplication2.Services
{
    public interface ICustomersRepository
    {
        IEnumerable<Customers> GetCustomers();
        CustomersVM GetByEmail(string email);
        CustomersVM GetCustomerById(int id);
        CustomersVM PutCustomers(int id, CustomersVM customers);
        void PostCustomers(CustomersVM customers);
        void DeleteCustomers(int id);
    }
}
