﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Data;
using WebApplication2.Models;

namespace WebApplication2.Services
{
    public interface ICartItemsRepository
    {
        List<CartItemsVM> GetCartItems();
        decimal GetTotalPrice(int id);
        List<CartItemsVM> GetCartItemsByCustomers(int id);
        CartItemsVM GetCartItems(int id);
        CartItemsVM PutCartItems(int id,CartItemsVM cartItem);
        void PostCartItems(CartItemsVM cartItem);
        void DeleteCartItems(int id);
    }
}
