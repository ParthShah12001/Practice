﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using WebApplication2.Data;
using WebApplication2.Models;

namespace WebApplication2.Helper
{
    public class ApplicationMapper : Profile
    {
        public ApplicationMapper()
        {
            CreateMap<CustomersVM, Customers>().ReverseMap();

            CreateMap<ProductsVM, Products>().ReverseMap();

            CreateMap<CartItemsVM, CartItems>().ReverseMap();

            CreateMap<OrderItemsVM, OrderItems>().ReverseMap();

            CreateMap<OrdersVM, Orders>().ReverseMap();
            
        }
    }
}
