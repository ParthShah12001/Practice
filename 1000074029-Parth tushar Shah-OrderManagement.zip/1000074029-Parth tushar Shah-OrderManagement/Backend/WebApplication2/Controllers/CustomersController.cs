﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using WebApplication2.Data;
using WebApplication2.Models;
using WebApplication2.Services;

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomersController : Controller
    {
        private readonly ICustomersRepository _customerServices;
        private IConfiguration _config;
        public CustomersController(ICustomersRepository customerServices, IConfiguration config)
        {
            _customerServices = customerServices;
            _config = config;
        }

        [HttpGet]
        public IEnumerable<Customers> GetCustomers()
        {
            return _customerServices.GetCustomers();
        }

        [HttpGet("{id}")]
        public IActionResult GetCustomers([FromRoute] int id)
        {
            var customer = _customerServices.GetCustomerById(id);
            return Ok(customer);
        }

        [HttpGet("login/{email}")]
        public IActionResult GetByEmail([FromRoute]string email)
        {
            var customer = _customerServices.GetByEmail(email);
            return Ok(customer);
        }

        [HttpPut("{id}")]
        public IActionResult PutCustomers([FromRoute] int id, [FromBody] CustomersVM customers)
        {
            var customer = _customerServices.PutCustomers(id, customers);
            return Ok(customer);
        }

        [HttpPost("LoginToken")]
        public IActionResult Login([FromBody]UserLogin userLogin)
        {
            var user = Authenticate(userLogin);
            if (user != null)
            {
                var token = Generate(user);
                return Ok(token);
            }
            return NotFound();
        }
        private string Generate(Customers user)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier,user.Customername),
                new Claim(ClaimTypes.Email,user.Customeremail)
            };

            var token = new JwtSecurityToken(_config["Jwt:Issuer"],
                _config["Jwt:Audience"],
                claims,
                expires: DateTime.Now.AddMinutes(15),
                signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private Customers Authenticate(UserLogin userLogin)
        {
            var totaldata = GetCustomers();
            var currentUser = totaldata.FirstOrDefault(o => o.Customeremail.ToLower() == userLogin.Customeremail.ToLower()
            && o.Customerpassword == userLogin.Customerpassword);
            if (currentUser != null)
            {
                return currentUser;
            }
            return null;
        }

        [HttpPost]
        public IActionResult PostCustomers([FromBody] CustomersVM customers)
        {
            _customerServices.PostCustomers(customers);
            return Ok();
        }
        [HttpDelete("{id}")]
        public IActionResult DeleteCustomers([FromRoute] int id)
        {
            _customerServices.DeleteCustomers(id);
            return Ok();
        }

        
    }
}

            