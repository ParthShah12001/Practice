﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApplication2.Data;
using WebApplication2.Models;
using WebApplication2.Services;

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartItemsController : Controller
    {
        private readonly ICartItemsRepository _cartItemsServices;
        public CartItemsController(ICartItemsRepository cartItemsServices)
        {
            _cartItemsServices = cartItemsServices;
        }

        [HttpGet]
        public IActionResult GetCartItems()
        {
            var items = _cartItemsServices.GetCartItems();
            return Ok(items);
        }

        [Authorize]
        [HttpGet("gettotal/{id}")]
        public IActionResult GetTotalPrice([FromRoute] int id)
        {
            var total = _cartItemsServices.GetTotalPrice(id);
            return Ok(total);
        }

        [Authorize]
        [HttpGet("customer/{id}")]
        public IActionResult GetCartItemsByCustomers([FromRoute] int id)
        {
            var item = _cartItemsServices.GetCartItemsByCustomers(id);
            return Ok(item);
        }

        [HttpGet("{id}")]
        public IActionResult GetCartItems([FromRoute] int id)
        {
            var item = _cartItemsServices.GetCartItems(id);
            return Ok(item);
        }

        [HttpPut("{id}")]
        public IActionResult PutCartItems([FromRoute] int id, [FromBody] CartItemsVM cartItems)
        {
            var item = _cartItemsServices.PutCartItems(id, cartItems);
            return Ok(item);
        }

        [HttpPost]
        public IActionResult PostCartItems([FromBody] CartItemsVM cartItems)
        {
            _cartItemsServices.PostCartItems(cartItems);
            return Ok();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCartItems([FromRoute] int id)
        {
            _cartItemsServices.DeleteCartItems(id);
            return Ok();
        }
    }
}