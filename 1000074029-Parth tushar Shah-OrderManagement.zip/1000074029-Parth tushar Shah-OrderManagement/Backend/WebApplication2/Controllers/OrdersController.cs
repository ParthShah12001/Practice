﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApplication2.Data;
using WebApplication2.Models;
using WebApplication2.Services;

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : Controller
    {

        private readonly IOrdersRepository _ordersServices;
        public OrdersController(IOrdersRepository ordersServices)
        {
            _ordersServices = ordersServices;
        }

        [HttpGet]
        public IActionResult GetOrders()
        {
            var item = _ordersServices.GetOrders();
            return Ok(item);
        }

        [Authorize]
        [HttpGet("customer/{id}")]
        public IActionResult GetOrderedItems([FromRoute] int id)
        {
            var item = _ordersServices.GetOrderedItems(id);
            return Ok(item);
        }

        [HttpGet("getlastorder")]
        public IActionResult GetLastOrder()
        {
            var item = _ordersServices.GetLastOrder();
            return Ok(item);
        }
        // GET: api/Orders/5
        [HttpGet("{id}")]
        public IActionResult GetOrders([FromRoute] int id)
        {
            var item = _ordersServices.GetOrders(id);
            return Ok(item);

        }

        // PUT: api/Orders/5
        [HttpPut("{id}")]
        public IActionResult PutOrders([FromRoute] int id, [FromBody] OrdersVM orders)
        {
            var item = _ordersServices.PutOrders(id, orders);
            return Ok(item);
        }

        // POST: api/Orders
        [HttpPost]
        public IActionResult PostOrders([FromBody] OrdersVM orders)
        {
            _ordersServices.PostOrders(orders);
            return Ok();
        }

        // DELETE: api/Orders/5
        [HttpDelete("{id}")]
        public IActionResult DeleteOrders([FromRoute] int id)
        {
            _ordersServices.DeleteOrders(id);
            return Ok();
        }
    }
}





