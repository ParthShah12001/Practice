﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApplication2.Data;
using WebApplication2.Models;
using WebApplication2.Services;

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : Controller
    {
        private readonly IProductsRepository _productsServices;
        public ProductsController (IProductsRepository productsServices)
        {
            _productsServices = productsServices;
        }

        private Customers GetCurrentUser()
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                var useClaims = identity.Claims;

                return new Customers
                {
                    Customername = useClaims.FirstOrDefault(o => o.Type == ClaimTypes.NameIdentifier)?.Value,
                    Customeremail = useClaims.FirstOrDefault(o => o.Type == ClaimTypes.Email)?.Value
                };
            }
            return null;
        }


        [HttpGet]
        [Authorize]
        public IActionResult GetProducts()
        {
            var currentUser = GetCurrentUser();
            if (currentUser != null)
            {
                var item = _productsServices.GetProducts();
                return Ok(item);
            }
            return null;
        }

        [HttpGet("{id}")]
        public IActionResult GetProducts([FromRoute] int id)
        {
            var item = _productsServices.GetProducts(id);
            return Ok(item);
        }

        [HttpPut("{id}")]
        public IActionResult PutProducts([FromRoute] int id, [FromBody] ProductsVM products)
        {
            var item = _productsServices.PutProducts(id, products);
            return Ok(item);
        }

        [HttpPost]
        public IActionResult PostProducts([FromBody] ProductsVM products)
        {
            _productsServices.PostProducts(products);
            return Ok();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteProducts([FromRoute] int id)
        {
            _productsServices.DeleteProducts(id);
            return Ok();
        }
    }
}