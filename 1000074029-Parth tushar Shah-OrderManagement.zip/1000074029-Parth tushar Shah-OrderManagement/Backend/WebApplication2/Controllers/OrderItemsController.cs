﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApplication2.Models;
using WebApplication2.Services;

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderItemsController : Controller
    {
        private readonly IOrderItemsRepository _orderItemsServices;

        public OrderItemsController(IOrderItemsRepository orderItemsServices)
        {
            _orderItemsServices = orderItemsServices;
        }

        [HttpGet]
        public IActionResult GetOrderItems()
        {
            var item = _orderItemsServices.GetOrderItems();
            return Ok(item);
        }

        [HttpGet("OrderItems/{id}")]
        public IActionResult GetOrderItemByCustomer([FromRoute] int id)
        {
            var item = _orderItemsServices.GetOrderItemByCustomer(id);
            return Ok(item);
        }

        [Authorize]
        [HttpGet("ordered/{orderid}/{id}")]
        public IActionResult GetOrderedItems([FromRoute] int id, [FromRoute]int orderid)
        {
            var item = _orderItemsServices.GetOrderedItems(id, orderid);
            return Ok(item);
        }


        // GET: api/OrderItems/5
        [HttpGet("{id}")]
        public IActionResult GetOrderItems([FromRoute] int id)
        {
            var item = _orderItemsServices.GetOrderItems(id);
            return Ok(item);
        }

        // PUT: api/OrderItems/5
        [HttpPut("{id}")]
        public IActionResult PutOrderItems([FromRoute] int id, [FromBody] OrderItems orderItems)
        {
            var item = _orderItemsServices.PutOrderItems(id, orderItems);
            return Ok(item);
        }

        // POST: api/OrderItems
        [HttpPost]
        public IActionResult PostOrderItems([FromBody] OrderItems orderItems)
        {
            _orderItemsServices.PostOrderItems(orderItems);
            return Ok();
        }

        // DELETE: api/OrderItems/5
        [HttpDelete("{id}")]
        public IActionResult DeleteOrderItems([FromRoute] int id)
        {
            _orderItemsServices.DeleteOrderItems(id);
            return Ok();
        }
    }
}
