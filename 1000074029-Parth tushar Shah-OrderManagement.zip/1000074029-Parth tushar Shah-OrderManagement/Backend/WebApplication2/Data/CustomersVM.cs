﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Data
{
    public class CustomersVM
    {
        public int Customerid { get; set; }
        public string Customername { get; set; }
        public string Customeremail { get; set; }
        public string Customerpassword { get; set; }
    }
}
