﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Data
{
    public class CartItemsVM
    {
        public int Itemid { get; set; }
        public int Productid { get; set; }
        public int Productquantity { get; set; }
        public decimal Productprice { get; set; }
        public int Customerid { get; set; }

    }
}
