﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Data
{
    public class ProductsVM
    {
        public int Productid { get; set; }
        public string Productname { get; set; }
        public string Productdetails { get; set; }
        public decimal Productprice { get; set; }
        public int Productquantity { get; set; }
        public string Imglinks { get; set; }
    }
}
