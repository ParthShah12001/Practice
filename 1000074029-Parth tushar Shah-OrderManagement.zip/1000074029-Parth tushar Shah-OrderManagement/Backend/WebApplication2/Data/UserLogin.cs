﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Data
{
    public class UserLogin
    {
        public string Customeremail { get; set; }
        public string Customerpassword { get; set; }

    }
}
