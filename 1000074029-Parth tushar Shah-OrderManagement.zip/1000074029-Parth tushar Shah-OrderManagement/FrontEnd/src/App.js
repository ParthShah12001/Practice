import './App.css';
import React from 'react';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import './index.css';
import Landing from './Landing';
import Login from './Login';
import Registration from './Registration';
import Products from './Products';
import Cart from './Cart';
const LazyHistory = React.lazy(()=>import('./OrderHistory'));
const LazyHistoryDetails = React.lazy(()=>import('./OrderDetails'));
const LazyProductDetails = React.lazy(() => import('./ProductDetails'));
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/">
          <Route index element={<Landing />} />
          <Route path="login" element={<Login />} />
          <Route path="register" element={<Registration />} />
          <Route path="loggedin/Products/:id" element={<Products />} />
          <Route path="loggedin/cart/:id" element={<Cart />} />
          <Route path="loggedin/myorders/:id" element={<React.Suspense fallback="Loading..."><LazyHistory /></React.Suspense>} />
          <Route path="loggedin/:productid/:id" element={<React.Suspense fallback="Loading..."><LazyProductDetails /></React.Suspense>} />
          <Route path="loggedin/orderid=:orderid/customerid=:id" element={<React.Suspense fallback="Loading..."><LazyHistoryDetails /></React.Suspense>} />
        </Route>
      </Routes>
    </BrowserRouter>
    
  );
}

export default App;
