import { useEffect, useState } from "react";
import { Button, Card, Container } from "react-bootstrap";
import emailjs from '@emailjs/browser';
const OrderItems = (props) =>{
    const[product, setProduct] = useState([]);
    const[item,setItem] = useState([]);
    
    const[checkEmail,setCheckEmail] = useState(false);
    useEffect(() =>{
      fetch(`http://localhost:56785/api/Products/${props.productid}`)
      .then(res => res.json())
      .then(res =>{
        setProduct(res)
      })

      fetch(`http://localhost:56785/api/OrderItems/${props.itemid}`)
      .then(res => res.json())
      .then(res =>{
        setItem(res)
      })

    })
    
    useEffect(() =>{
      if(checkEmail){
        window.location.reload();
      }
    },[checkEmail])


    const ActionOnCancle = () =>{
        fetch(`http://localhost:56785/api/OrderItems/${props.itemid}/`,{
            method:'PUT',
            headers:{
              'Accept':'application/json',
              'Content-Type':'application/json'
            },
            body:JSON.stringify({...item,"stat":"cancle"})
          })

          var templateparams={
            "from_name":"Seller",
            "message":`Your Order of ${product.productname} from order id ${props.orderid} has been cancelled successfully. If you purchased the product via online payment method your money will me returned to your bank account in 7 business day. Thank you`
          }
        emailjs.send('service_50gmywn', 'template_2fuqijc', templateparams, 'IwpiSK40hoj4-I3yM')
          .then((result) => {
              console.log(result.text);
              setCheckEmail(true);
          }, (error) => {
              console.log(error.text);
          });
    }
    return(
        <div>
           <Container>
        <div>
        <Card style={{width:"27.5vw",marginLeft:"28vw",marginTop:"3vw",background:"#B0AEAD"}}>
        <Card.Body>
        <Card.Img src={product.imglinks} style={{height:"25vw", width:"25vw"}}/>
            <Card.Text>
                <h1>{product.productname}</h1>
                {product.productdetail}
                <h5>Quantity: {props.quant}</h5>
                <h5>Price: {product.productprice}</h5>
                <h5>Total Price: Rs. {product.productprice * props.quant}</h5>
                <h5>Status: {props.stat}</h5>
          </Card.Text>
          {props.stat==="placed" &&
          <Button variant="primary" onClick={ActionOnCancle}>Cancle</Button>
            }
            {props.stat==="cancled" &&
          <Button variant="primary" onClick={ActionOnCancle} disabled={true}>Cancle</Button>
            }
        </Card.Body>
      </Card>
      
      <br></br>
      </div>
        </Container>
    </div>
    );
}

export default OrderItems;