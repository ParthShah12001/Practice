import OrderItems from "./OrderItems";
import { useEffect, useState } from "react";
import { Container } from "react-bootstrap";
import{ useParams} from "react-router-dom";
import Internalnav from "./Internalnav";

const OrderDetails = () =>{
    const{orderid,id} = useParams();
    const[items,setItems] = useState([]);
    
    useEffect(() =>{
        let token = JSON.parse(localStorage.getItem('login'))
        
      if(token.token!=null){
        fetch(`http://localhost:56785/api/OrderItems/ordered/${orderid}/${id}`,{headers: {"Authorization":"Bearer "+token.token,'Content-Type':'application/json'}})
        .then(response => response.json())
        .then(res =>{
            console.log(res);
            setItems(res);
        }).catch(error => console.log(error))
        }
        
    else{
        alert("Unauthorized user");
    }


    },[])

    return(
        <div  >
            <Internalnav />

        <Container style={{marginTop:"5rem"}}>
            <br></br>
            <h1>You Order Details</h1>
            <br></br>
            <h5>Detailed History of all the products in the order</h5>
            <br></br>
            <div key={id}>
                {items?.map( e=> (
                    <OrderItems productid={e.productid} itemid={e.itemid} quant={e.quantity} stat = {e.stat} orderid={orderid}/>
                ))}
            </div>
        </Container>     
      </div>
    );
}

export default OrderDetails;