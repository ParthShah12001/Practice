import { useEffect, useState } from "react";
import { Button, Card, Container } from "react-bootstrap";
import {  Nav, Navbar } from "react-bootstrap";
import { useNavigate, useParams } from "react-router-dom";
import Internalnav from "./Internalnav";
import Col from 'react-bootstrap/Col'
import Row from 'react-bootstrap/Row'
import {Grid} from '@mui/material'
const Products = () =>{
    const navigate=useNavigate();
    const {id} = useParams();
    const [prod,setProd] = useState([])
    const[searchTerm,setSearchTerm] = useState("");

  useEffect(() =>{
    let token = JSON.parse(localStorage.getItem('login'))
    
    if(token.token!=null){
    fetch(`http://localhost:56785/api/Products`,{headers: {"Authorization":"Bearer "+token.token,'Content-Type':'application/json'}})
    .then(res => res.json())
    .then(res =>{
      setProd(res)
    })
    .catch(error => console.log(error))
  }
  else{
    alert("Unauthorized user")
  }
  },[])

  const handleDetails = (e) =>{
    navigate(`/loggedin/${e.productid}/${id}`)
  }
   
    return (
        <div>
          
            <Internalnav />
        <Container style={{marginTop:"5rem"}}>
          <br></br>
          <h1>Products</h1>
          <br></br>
          <h5>Browser through exciting range of products</h5>
          <br></br>
          <h6>Enter then make of product you are looking for</h6>
          <input type="text" placeholder="Search...." onChange={(event) =>{setSearchTerm(event.target.value)}}/>
        <div>
        <Row xs={1} md={3} className="g-4">
          {prod.filter((e) =>{
            if(searchTerm== ""){
              return(
                <Col>
                <Card style={{width:"23.5vw",marginTop:"3vw",background:"#B0AEAD"}}>
                  <div style={{display:"inline-block"}}>
                    <Card.Body>
                      <Card.Img src={e.imglinks} style={{height:"25vw", width:"21vw"}}/>
                  
                      <Card.Text>
                        <br></br>
                        <h1>{e.productname}</h1>
                        {e.productdetail}
                        <h5>Rs. {e.productprice}</h5>
                      </Card.Text> 
                      <Button variant="primary" onClick={() => handleDetails(e)}>Details</Button>
                    </Card.Body>
                  </div>
                </Card>
                </Col>
              )
            }
            else if(e.productname.toLowerCase().includes(searchTerm.toLowerCase())){
               return(
                 <Col>
                <Card style={{width:"23.5vw",marginTop:"3vw",background:"#B0AEAD"}}>
                <div style={{display:"inline-block"}}>
                  <Card.Body>
                    <Card.Img src={e.imglinks} style={{height:"25vw", width:"21vw"}}/>
                
                    <Card.Text>
                      <br></br>
                      <h1>{e.productname}</h1>
                      {e.productdetail}
                      <h5>Rs. {e.productprice}</h5>
                    </Card.Text> 
                    <Button variant="primary" onClick={() => handleDetails(e)}>Details</Button>
                  </Card.Body>
                </div>
              </Card>
              </Col>
               );
            }

          }).map( e=> (
        <Col>
        <Card style={{width:"23.5vw",marginTop:"3vw",background:"#B0AEAD"}}>
          <div style={{display:"inline-block"}}>
            <Card.Body>
              <Card.Img src={e.imglinks} style={{height:"25vw", width:"21vw"}}/>
          
              <Card.Text>
                <br></br>
                <h1>{e.productname}</h1>
                {e.productdetail}
                <h5>Rs. {e.productprice}</h5>
              </Card.Text> 
              <Button variant="primary" onClick={() => handleDetails(e)}>Details</Button>
            </Card.Body>
          </div>
        </Card>
        </Col>
      
      ))}
      </Row>
      <br></br>
      </div>
        </Container>
        
    </div>
    );
}
export default Products;