Create Table Customers(
	customerid int primary key Identity(1,1),
	customername varchar(100) not null,
	customeremail varchar(100) not null,
	customerpassword varchar(100) not null
);

Create table Products(
	productid int primary key Identity(1,1),
	productname varchar(100) not null,
	productdetail varchar(500) not null,
	productprice decimal(13,2) not null,
	productquantity int not null
);

Create table CartItems(
	itemid int primary key Identity(1,1),
	productid int not null,
	customerid int not null,
	productquantity int not null,
	productprice decimal(13,2) not null,
	Foreign key(productid) references Products(productid),
	Foreign key(customerid) references Customers(customerid)
);

Create table Orders (
	orderid int primary key,
	customerid int not null,
	totalprice decimal(13,2) not null,
	paymentMethod varchar(100) not null,
	addres varchar(500) not null,
	city varchar(150) not null,
	region varchar(150) not null,
	orderdate Date not null,
	Foreign key(customerid) references Customers(customerid)
);

Create Table OrderItems(
	itemid int primary key Identity(1,1),
	productid int not null,
	customerid int not null,
	orderid int not null,
	quantity int not null,
	price decimal(13,2) not null,
	stat varchar(100) not null,
	Foreign key(productid) references Products(productid),
	Foreign Key(customerid) references Customers(customerid),
	Foreign Key(orderid) references Orders(orderid)
);

